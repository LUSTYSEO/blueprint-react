# ETAPA 2: ARQUITETURA DE INFRAESTRUTURA ANTI-BLOQUEIO, PROXIES RESIDENCIAIS E ISOLAMENTO DE IDENTIDADES GLOBAIS

---

## 2.1 A Anatomia do Rastreamento Algorítmico e Fingerprinting Digital

A execução de uma operação de distribuição massiva voltada para mercados internacionais exige a compreensão profunda dos mecanismos de segurança das plataformas hospedeiras (Google/YouTube, ByteDance/TikTok, Meta). O objetivo dessas corporações é proteger a integridade do seu inventário publicitário contra bots, fazendas de cliques e redes de spam coordenadas.

Quando um operador no Brasil tenta criar ou gerenciar simultaneamente múltiplos canais direcionados aos Estados Unidos ou Europa a partir de um navegador comercial convencional (Chrome, Edge ou Safari), os sistemas de análise de risco acionam restrições silenciosas (*Shadowban*), suspensões preventivas ou a rejeição imediata da monetização no AdSense.

```
                      VETORES DE IDENTIFICAÇÃO DIGITAL
                      
+--------------------------------------------------------------------------+
|                          ENDEREÇO IP & REDE                              |
|   - Tipo de IP (Datacenter / Hosting vs. Residencial / ISP)              |
|   - ASN (Autonomous System Number) & Reputação de Fraude                 |
|   - Vazamentos de DNS e WebRTC (Exposição do IP Real Local)              |
+--------------------------------------------------------------------------+
                                     |
                                     v
+--------------------------------------------------------------------------+
|                       BROWSER FINGERPRINTING                             |
|   - Canvas Fingerprint (Assinatura de renderização da GPU)               |
|   - WebGL Metadata & Unmasked Renderer (Placa de vídeo física)           |
|   - AudioContext Fingerprint (Variação de microfrequências de áudio)     |
|   - Enumeração de Fontes do Sistema & Resolução Real da Tela             |
+--------------------------------------------------------------------------+
                                     |
                                     v
+--------------------------------------------------------------------------+
|                     TELEMETRIA COMPORTAMENTAL (BEHAVIOR)                 |
|   - Ausência de histórico pregresso de navegação (Cookies "frios")       |
|   - Padrões de digitação não humanos e cliques instantâneos              |
|   - Sincronização incorreta de Fuso Horário, Geolocation API e Locale    |
+--------------------------------------------------------------------------+
```

### O Conceito de Browser Fingerprinting

O *Browser Fingerprinting* (impressão digital do navegador) é uma técnica probabilística de rastreamento que dispensa o uso de cookies. Ao acessar uma página, scripts em segundo plano solicitam que o navegador processe tarefas gráficas, sonoras e de sistema:

1. **Canvas & WebGL Fingerprinting:** O script instrui o navegador a desenhar uma forma geométrica oculta em 2D/3D e aplicar texturas. Como cada placa de vídeo (GPU), versão de driver e renderizador processa frações de pixels com variações invisíveis ao olho humano, a imagem final gera um valor de hash criptográfico único.
2. **AudioContext Fingerprinting:** Mede a forma precisa como o hardware do computador processa ondas senoidais de áudio. A resposta em frequência do subsistema de áudio identifica a máquina física.
3. **Hardware Concurrency & Device Memory:** As plataformas leem a quantidade de núcleos de processador (`navigator.hardwareConcurrency`) e memória RAM (`navigator.deviceMemory`) disponíveis. Ambientes virtualizados genéricos ou servidores VPS baratos são imediatamente catalogados por possuírem configurações atípicas para usuários domésticos comuns.

---

## 2.2 A Tríade de Isolamento Operacional

Para neutralizar a correlação entre contas e proteger cada canal contra penalizações em cascata, a operação deve ser dividida em **ambientes estritamente compartimentados**. Se o Canal A sofrer uma advertência, o Canal B e a conta central do AdSense devem permanecer blindados e invisíveis à correlação algorítmica.

```
+--------------------------------------------------------------------------+
|                        CONTAINER DE ISOLAMENTO TOTAL                     |
|                                                                          |
|  [ Perfil Anti-Detect Isolado ]                                          |
|  ├── Sistema Operacional Simulado: macOS Sonoma / Windows 11             |
|  ├── Canvas / WebGL / AudioContext: Ruído de hardware exclusivo           |
|  ├── Resolução de Tela: Nativa simulada (ex: 1920x1080)                  |
|  └── Fuso Horário & Idioma: America/New_York (en-US)                     |
|                                                                          |
|  [ Conexão de Rede Dedicada ]                                            |
|  ├── Proxy Residencial Estático (ISP): AT&T / Comcast (EUA)              |
|  ├── WebRTC: Substituído pelo IP do Proxy (Zero Leaks)                  |
|  └── DNS: Resolvido diretamente no país de destino                       |
|                                                                          |
|  [ Identidade Operacional ]                                              |
|  ├── E-mail Próprio com Domínio Exclusivo                                |
|  ├── Chave 2FA (Autenticador TOTP) sem dependência de SMS                |
|  └── Pote de Cookies Acumulados (Histórico de Navegação Prévia)          |
+--------------------------------------------------------------------------+
```

### O Papel dos Navegadores Anti-Detect

Softwares anti-detect profissionais (como Dolphin{anty}, AdsPower, Multilogin ou GoLogin) não se limitam a limpar cookies ou operar em "modo anônimo". Eles controlam o código-fonte do motor do Chromium para injetar parâmetros falsos, porém matematicamente consistentes, em todas as APIs consultadas pelas redes sociais:

* **Injeção de Ruído no Canvas:** Em vez de bloquear o Canvas (o que acionaria um alerta imediato de bot), o software adiciona um ruído imperceptível aos pixels de saída. A cada perfil criado, uma assinatura digital diferente é gerada.
* **Spoofing de WebGL:** Modifica os campos `UNMASKED_VENDOR_WEBGL` e `UNMASKED_RENDERER_WEBGL`, fazendo com que os servidores do Google e TikTok acreditem que o dispositivo possui uma GPU comum de consumo (ex.: NVIDIA GeForce RTX 3060 ou Apple M2), mascarando ambientes de servidores ou hardwares idênticos.
* **Alinhamento de Fuso Horário e Geolocalização:** O navegador consulta o IP do proxy atribuído e ajusta automaticamente o relógio interno do navegador, o cabeçalho de idioma (`Accept-Language: en-US,en;q=0.9`) e as coordenadas de latitude/longitude retornadas pela Geolocation API.

---

## 2.3 Engenharia de Rede: Tipologia e Alocação de Proxies

O endereço IP representa a camada primária de triagem de tráfego. Utilizar provedores de VPN convencionais ou proxies corporativos de Datacenter é o caminho mais rápido para a inviabilização de uma conta internacional.

### Tabela Comparativa de Tipos de Conexão:

| Tipo de Conexão | Origem do IP | Classificação ASN | Risco de Bloqueio | Custo Relativo | Aplicação no Projeto |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **VPN Comercial** (Nord, Express, etc.) | Servidores Compartilhados | Hosting / Datacenter | **Crítico (95%)** | Baixo | **Proibido.** Pools de IPs públicos com histórico de abuso massivo. |
| **Proxy de Datacenter** (VPS / AWS / Vultr) | Servidores de Nuvem | Datacenter | **Alto (75%)** | Baixo | Inadequado para login em redes sociais; útil apenas para scraping. |
| **Proxy Residencial Rotativo** | Dispositivos Domésticos | ISP (Comcast, AT&T) | **Médio (30%)** | Médio (por GB) | Útil para coleta de dados de concorrentes e APIs, não para manter contas. |
| **Proxy Residencial Estático (ISP)** | Provedores Residenciais Fixos | ISP / Residencial | **Mínimo (< 2%)** | Médio/Alto (Fixo) | **Obrigatório.** IP fixo, ASN legítimo, sem rotação de sessão. |

```
                  FLUXO DE DECISÃO DE CONECTIVIDADE
                  
                      [ Seleção de Tráfego ]
                                |
               +----------------+----------------+
               |                                 |
               v                                 v
      [ IP de Datacenter ]              [ IP Residencial Estático ]
       ASN: Hosting/Cloud                 ASN: Residential/ISP
               |                                 |
               v                                 v
  Checkpoints de Segurança          Navegação Transparente
  - Captchas constantes              - Sem alertas de login
  - Suspensão de Canais              - Acesso direto ao YouTube Studio
  - Bloqueio de Monetização          - Alta pontuação de confiança
```

### Protocolo de Validação de Saúde de Rede

Antes de vincular qualquer proxy a um perfil de canal, o operador deve executar um diagnóstico técnico nas seguintes ferramentas especializadas:

1. **IPHey (iphey.com):** A taxa de confiabilidade do perfil deve retornar o status **"Trustworthy"** em todos os vetores (Browser, Location, IP, Hardware).
2. **Pixelscan (pixelscan.net):** Nenhuma inconsistência de fingerprint deve ser detectada (*Zero Fingerprint Inconsistencies*).
3. **Scamalytics (scamalytics.com):** O *Fraud Score* do endereço IP deve registrar valor inferior a **15 / 100**. Índices superiores indicam que o IP foi previamente utilizado para atividades de automação agressiva.

### Estrutura de Configuração Técnica (`config/proxies.json`)

Para integrar a esteira de automação com agentes e garantir rastreabilidade, os proxies devem ser catalogados de forma estruturada:

```json
{
  "clusters": [
    {
      "cluster_id": "us_tier1_finance",
      "target_country": "US",
      "state": "VA",
      "timezone": "America/New_York",
      "proxy": {
        "type": "socks5",
        "host": "isp-us.residential-node.com",
        "port": 10808,
        "username": "auth_client_01",
        "password": "secure_token_alphanumeric"
      },
      "assigned_accounts": [
        "youtube_channel_01",
        "tiktok_account_01",
        "pinterest_board_01"
      ]
    },
    {
      "cluster_id": "eu_tier1_tech",
      "target_country": "DE",
      "state": "HE",
      "timezone": "Europe/Berlin",
      "proxy": {
        "type": "socks5",
        "host": "isp-de.residential-node.com",
        "port": 10809,
        "username": "auth_client_02",
        "password": "secure_token_alphanumeric"
      },
      "assigned_accounts": [
        "youtube_channel_02",
        "tiktok_account_02"
      ]
    }
  ]
}
```

---

## 2.4 Protocolo de Criação e Aquecimento de Contas (Warm-Up)

Uma das causas mais frequentes de desativação prematura de canais é o comportamento afobado do operador. Criar uma conta no Google e, na primeira hora, fazer o upload de múltiplos vídeos aciona os filtros heurísticos de spam. Contas recém-criadas exigem um **processo de maturação gradual (Warm-Up)** de 14 dias para simular a pegada de navegação de um usuário humano real.

```
CRONOGRAMA DE AQUECIMENTO DE CONTAS (14 DIAS)

Dias 1-3   [ Coleta de Cookies ]     Navegação passiva em grandes portais gringos
                 |
Dias 4-6   [ Ativação Social ]       Criação de contas secundárias e buscas no YouTube
                 |
Dias 7-9   [ Criação da Conta ]      Abertura do canal YouTube Studio + 2FA App
                 |
Dias 10-12 [ Customização ]          Upload de Banner, Avatar, Bio e Links oficiais
                 |
Dias 13-14 [ Upload Não Listado ]    Teste de Content ID e liberação final
```

### O Protocolo dos 14 Dias

#### Fase 1: Coleta e Injeção de Cookies Orgânicos (Dias 1 a 3)
* **Objetivo:** Eliminar a característica de "navegador zerado". Usuários comuns possuem histórico de navegação acumulado em milhares de sites.
* **Ação:** Dentro do perfil anti-detect com o proxy ISP ativo, navegar por 20 a 30 minutos diários em grandes sites de notícias e comércio dos EUA (CNN, Amazon, Wikipedia, The New York Times, Reddit). Permitir que os sites depositem seus cookies de rastreamento no perfil. Softwares anti-detect avançados oferecem a função de *Cookie Bot*, que automatiza essa navegação prévia por URLs pré-programadas.

#### Fase 2: Pesquisa Ativa e Consumo Passivo (Dias 4 a 6)
* **Objetivo:** Sinalizar interesse algorítmico pelo nicho que o canal irá operar.
* **Ação:** Entrar no YouTube sem fazer login. Realizar buscas orgânicas pelos termos principais do seu nicho. Assistir a 3 ou 4 vídeos completos de concorrentes mapeados na Etapa 1. Deixar o algoritmo do YouTube moldar a página inicial para o idioma e o contexto do público americano.

#### Fase 3: Criação de Identidade e Autenticação Forte (Dias 7 a 9)
* **Objetivo:** Estabelecer a conta do Google/YouTube com blindagem contra recuperação indevida.
* **Ação:**
  1. Criação do Gmail utilizando o proxy residencial e o navegador anti-detect.
  2. Caso a plataforma solicite verificação por SMS, utilizar exclusivamente números móveis privados de operadoras reais dos EUA/Reino Unido (evitar serviços públicos de SMS descartável; utilizar plataformas de ativação única *Non-VoIP*).
  3. **A Armadilha do 2FA:** Assim que a conta for validada, acessar as configurações de segurança do Google e ativar a **Verificação em Duas Etapas via Aplicativo Autenticador (TOTP)**, como Google Authenticator ou Bitwarden. Salvar os 10 códigos de backup em local seguro.
  4. Remover o número de telefone temporário do perfil para evitar bloqueios futuros caso a linha seja reciclada pela operadora. A chave TOTP e os códigos de backup garantem controle de acesso permanente.

#### Fase 4: Personalização de Marca e Metadata (Dias 10 a 12)
* **Objetivo:** Transformar a conta de consumo em um canal estruturado.
* **Ação:**
  1. Acessar o YouTube Studio. Configurar o nome do canal, identificador único (@handle), descrição detalhada contendo as palavras-chave semânticas do nicho e país de residência do canal definido estritamente como **Estados Unidos** (ou país de destino da audiência).
  2. Upload dos ativos visuais: Avatar de alta resolução, Banner responsivo e marca d'água de canto de tela.
  3. Inserir links externos oficiais na aba de personalização (link da micro landing page ou perfil associado).

#### Fase 5: O Upload Neutro e Verificação de Content ID (Dias 13 e 14)
* **Objetivo:** Validar a recepção da plataforma sem exposição prematura ao algoritmo público.
* **Ação:**
  1. Realizar o upload do primeiro vídeo de teste em modo **Não Listado (Unlisted)** ou **Privado (Private)**.
  2. Aguardar 24 horas. Verificar se o sistema de checagem do YouTube (*Checks*) aprova o áudio e os elementos visuais sem restrições de direitos autorais (*Copyright Claim*) ou limitações de adequação para anunciantes (*Yellow Dollar*).
  3. No dia 14, alterar o status do primeiro vídeo oficial para **Público (Public)** ou agendar para o horário nobre de consumo da costa leste americana (entre 14h e 17h EST).

---

## 2.5 Matriz de Isolamento de Clusters Operacionais

Para operações que visam escala acelerada com 3 a 10 canais, adota-se o modelo de **Clusters Operacionais Herméticos**. Cada cluster agrega uma família de redes sociais que orbita em torno de um mesmo ativo ou subnicho, compartilhando o mesmo proxy ISP dedicado, mas completamente isolado dos demais clusters.

```
ESTRUTURA DE CLUSTERS HERMÉTICOS

+--------------------------------------------------------------------------+
| CLUSTER 1: ECOSSISTEMA FINANCEIRO (US)                                   |
| - Proxy: SOCKS5 Residencial Estático (New York - AT&T)                   |
| - Perfil Anti-Detect: Profile_US_Fin_01                                  |
| - Ativos Conectados: Canal YouTube Finanças, TikTok US, Twitter/X, Stripe|
+--------------------------------------------------------------------------+
                                    X (ISOLAMENTO TOTAL)
+--------------------------------------------------------------------------+
| CLUSTER 2: ECOSSISTEMA GAMING / GTA 6 (US)                               |
| - Proxy: SOCKS5 Residencial Estático (Miami - Comcast)                   |
| - Perfil Anti-Detect: Profile_US_Game_01                                 |
| - Ativos Conectados: Canal YouTube Gaming, TikTok US, Discord, Amazon US |
+--------------------------------------------------------------------------+
                                    X (ISOLAMENTO TOTAL)
+--------------------------------------------------------------------------+
| CLUSTER 3: ECOSSISTEMA PRODUTIVIDADE / TECH (DE/EU)                      |
| - Proxy: SOCKS5 Residencial Estático (Frankfurt - Deutsche Telekom)      |
| - Perfil Anti-Detect: Profile_EU_Tech_01                                 |
| - Ativos Conectados: Canal YouTube Tech DE, TikTok DE, Notion Affiliate  |
+--------------------------------------------------------------------------+
```

### Regras de Ouro da Não-Contaminação Cruzada:
1. **Zero Compartilhamento de Sessão:** Jamais abrir contas de clusters diferentes no mesmo navegador comum, celular pessoal ou perfil compartilhado.
2. **Isolamento de Credenciais de Pagamento:** Contas bancárias e métodos de recebimento (ex.: contas globais de pessoa jurídica, Wise Business, Payoneer ou Stripe) devem ser vinculados por meio de suas respectivas chaves de API ou acessados unicamente pelos perfis autorizados de cada jurisdição.
3. **Imunidade contra Queda Coletiva:** Se uma das contas de um cluster violar termos de serviço ou receber um strike de direitos autorais, os outros clusters operam em endereços IP, fingerprints de hardware e identidades fiscais dissociadas, garantindo que o fluxo de caixa dos projetos saudáveis permaneça intocado.

---

## 2.6 Checklist Tático de Conclusão da Etapa 2

Antes de avançar para a montagem da engenharia de roteiros e produção acelerada com Claude Code na **Etapa 3**, o ambiente operacional deve cumprir rigorosamente os seguintes critérios técnicos:

- [ ] **Software Anti-Detect Configurado:** Perfil dedicado instalado e validado para cada um dos canais previstos.
- [ ] **Proxy Residencial Estático (ISP) Ativo e Vinculado:** Proxy exclusivo do país de destino conectado ao perfil, com teste em *iphey.com* confirmando status *"Trustworthy"*.
- [ ] **Zero Vazamento de WebRTC e DNS:** Endereço de IP brasileiro do operador totalmente oculto sob varredura do *pixelscan.net*.
- [ ] **Protocolo de Warm-Up de 14 Dias Concluído:** Perfil alimentado com cookies reais de navegação e histórico compatível com o país-alvo.
- [ ] **Blindagem 2FA via Aplicativo (TOTP):** Verificação em duas etapas ativada via aplicativo autenticador, códigos de backup armazenados em cofre de senhas e telefone temporário desvinculado.
- [ ] **Metadados e Identidade Visual Aplicados:** Canal formatado com país definido nos EUA/Europa, links de funil inseridos e layout de capa/avatar em nível profissional.