ETAPA 5: ESTEIRA AUDIOVISUAL AUTOMATIZADA: SÍNTESE VOCAL NATIVA, AQUISIÇÃO DE B-ROLL E RENDERIZAÇÃO PROGRAMÁTICA VIA FFMPEG

5.1 Engenharia de Síntese Vocal (TTS) Nativa e Alinhamento Temporal

O componente acústico de um canal faceless internacional determina a retenção
inicial e a credibilidade do conteúdo. Audiências de países Tier 1 (Estados
Unidos, Reino Unido e Canadá) possuem alta sensibilidade a sotaques artificiais,
entonações robotizadas ou cadências monótonas.

Para alcançar qualidade indistinguível de um locutor humano profissional, o
pipeline integra-se a motores de síntese vocal neural de última geração
(ElevenLabs ou Fish Audio), extraindo não apenas o arquivo de áudio masterizado,
mas também os marcadores de alinhamento temporal por palavra (Word-Level
Timestamps), essenciais para a queima programática de legendas dinâmicas.

                  FLUXO DE SÍNTESE VOCAL E TEMPORALIZAÇÃO
                  
   +---------------------------------------------------------------+
   |        ROTEIRO JSON (voiceover_script de scriptwriter.py)     |
   +---------------------------------------------------------------+
                                   |
                                   v
   +---------------------------------------------------------------+
   |             MOTOR DE SÍNTESE VOCAL NEURAL (API)               |
   |      Modelos: ElevenLabs Multilingual v2 / Fish Audio         |
   |     Voice Profile: Narrador Analítico / Deep Tone (en-US)     |
   +---------------------------------------------------------------+
                                   |
                  +----------------+----------------+
                  |                                 |
                  v                                 v
   +------------------------------+   +----------------------------+
   |   ÁUDIO MESTRE (.MP3/.WAV)   |   |   TIMESTAMPS POR PALAVRA   |
   |  Taxa de Amostragem: 44.1kHz |   |     (JSON / Whisper Alignment) |
   |  Normalização: -14 LUFS      |   |  Start / End por vocábulo  |
   +------------------------------+   +----------------------------+
                  |                                 |
                  +----------------+----------------+
                                   |
                                   v
   +---------------------------------------------------------------+
   |             GERAÇÃO DE LEGENDA ESTILIZADA (.SRT/.ASS)         |
   |      Formatação dinâmica: 2 a 3 palavras por tela             |
   +---------------------------------------------------------------+

O Módulo de Geração de Áudio e Alinhamento (agents/media_generator.py)

O script abaixo consome o roteiro em JSON gerado pelo Claude Code na Etapa 4,
envia o texto consolidado para a API de síntese e produz tanto o áudio final
quanto o arquivo de legendas sincronizado:

"""
agents/media_generator.py
Responsável pela síntese de áudio neural e geração de arquivos de legenda com precisão milimétrica.
"""

import os
import json
import argparse
import logging
from typing import Dict, Any, List
import requests
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - [AUDIO] - %(levelname)s - %(message)s")

ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")
# ID de voz validada para documentários e canais analíticos (ex: tom profundo e formal)
DEFAULT_VOICE_ID = "pNInz6obpgDQGcFmaJgB" 

class AudioEngine:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("ELEVENLABS_API_KEY não configurada.")
        self.api_key = api_key
        self.base_url = "https://api.elevenlabs.io/v1"

    def synthesize_speech_with_timestamps(self, script_data: Dict[str, Any], output_audio_path: str, output_srt_path: str):
        """Sintetiza áudio com timestamps detalhados para legendagem sincronizada."""
        # Consolidar todo o texto da narração
        full_text = " ".join([segment["audio_text"] for segment in script_data["voiceover_script"]])
        
        headers = {
            "xi-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "text": full_text,
            "model_id": "eleven_turbo_v2_5",
            "voice_settings": {
                "stability": 0.45,
                "similarity_boost": 0.85,
                "style": 0.05,
                "use_speaker_boost": True
            }
        }

        logging.info(f"Enviando requisição de síntese vocal ({len(full_text)} caracteres)...")
        
        # Endpoint com retorno de alinhamento temporal por caractere/palavra
        url = f"{self.base_url}/text-to-speech/{DEFAULT_VOICE_ID}/with-timestamps"
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code != 200:
            raise RuntimeError(f"Erro na API de Voz: {response.status_code} - {response.text}")

        res_data = response.json()
        
        # 1. Salvar o arquivo de áudio binário decodificado de base64
        import base64
        audio_bytes = base64.b64decode(res_data["audio_base64"])
        os.makedirs(os.path.dirname(output_audio_path), exist_ok=True)
        with open(output_audio_path, "wb") as f:
            f.write(audio_bytes)
        logging.info(f"Áudio mestre salvo em: {output_audio_path}")

        # 2. Processar alinhamento e gerar arquivo de legenda .SRT dinâmico
        alignment = res_data.get("alignment", {})
        self._build_dynamic_srt(alignment, output_srt_path)
        logging.info(f"Legendas dinâmicas geradas em: {output_srt_path}")

    def _build_dynamic_srt(self, alignment: Dict[str, Any], srt_path: str):
        """Converte dados de alinhamento em blocos curtos de 2 a 3 palavras para retenção extrema."""
        characters = alignment.get("characters", [])
        char_start_times = alignment.get("character_start_times_seconds", [])
        char_end_times = alignment.get("character_end_times_seconds", [])

        # Reconstruir palavras a partir dos caracteres e seus tempos
        words = []
        current_word = ""
        word_start = None

        for idx, char in enumerate(characters):
            if char != " ":
                if not current_word:
                    word_start = char_start_times[idx]
                current_word += char
            else:
                if current_word:
                    words.append({
                        "word": current_word,
                        "start": word_start,
                        "end": char_end_times[idx - 1]
                    })
                    current_word = ""
                    word_start = None

        if current_word:
            words.append({
                "word": current_word,
                "start": word_start,
                "end": char_end_times[-1]
            })

        # Agrupar palavras em blocos de 3 para o formato vertical (estilo dinâmico)
        chunk_size = 3
        srt_entries = []
        counter = 1

        for i in range(0, len(words), chunk_size):
            chunk = words[i:i + chunk_size]
            text = " ".join([w["word"] for w in chunk]).upper()
            start_time = self._format_timestamp(chunk[0]["start"])
            end_time = self._format_timestamp(chunk[-1]["end"])

            srt_entries.append(f"{counter}\n{start_time} --> {end_time}\n{text}\n\n")
            counter += 1

        os.makedirs(os.path.dirname(srt_path), exist_ok=True)
        with open(srt_path, "w", encoding="utf-8") as f:
            f.writelines(srt_entries)

    @staticmethod
    def _format_timestamp(seconds: float) -> str:
        """Converte float em formato padrão SRT: HH:MM:SS,mmm"""
        hrs = int(seconds // 3600)
        mins = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds - int(seconds)) * 1000)
        return f"{hrs:02d}:{mins:02d}:{secs:02d},{millis:03d}"

def main():
    parser = argparse.ArgumentParser(description="Gerador de Áudio e Sincronia")
    parser.add_argument("--script", type=str, required=True, help="Arquivo JSON com o roteiro")
    parser.add_argument("--out-audio", type=str, default="cache/audio_master.mp3")
    parser.add_argument("--out-srt", type=str, default="cache/subtitles.srt")
    args = parser.parse_args()

    with open(args.script, "r", encoding="utf-8") as f:
        script_data = json.load(f)

    engine = AudioEngine(ELEVENLABS_API_KEY)
    engine.synthesize_speech_with_timestamps(script_data, args.out_audio, args.out_srt)

if __name__ == "__main__":
    main()

5.2 Aquisição Programática de B-Roll e Ativos Visuais

Para alimentar a regra de quebra de padrão a cada 1.5 a 2.5 segundos detalhada
na Etapa 3, um vídeo de 60 segundos requer entre 25 e 35 clipes visuais
distintos. Adquirir esses ativos manualmente inviabilizaria qualquer tentativa
de escala industrial.

A esteira utiliza um Mecanismo de Despacho Visual:

1.  Lê o campo visual_prompt de cada segmento do JSON do roteiro.
2.  Consulta APIs de bancos de mídia em alta resolução (Pexels API, Pixabay API)
    buscando por vídeos verticais (formato retrato, 1080 \times 1920).
3.  Caso a consulta não retorne resultados precisos, o script aplica um
    algoritmo de fallback para termos conceituais universais (ex.: "abstract
    dark technology", "financial market chart", "cinematic focus").
4.  Efetua o download simultâneo dos arquivos em pastas temporárias com nomes
    ordenados numericamente.

"""
Módulo complementar de aquisição de mídia (extraído para integração no pipeline).
"""
import os
import requests
import logging

PEXELS_API_KEY = os.getenv("PEXELS_API_KEY")

def download_broll_clip(query: str, target_filepath: str, orientation: str = "portrait"):
    """Busca e faz download do clipe mais relevante via Pexels API."""
    headers = {"Authorization": PEXELS_API_KEY}
    url = f"https://api.pexels.com/videos/search?query={query}&per_page=1&orientation={orientation}"
    
    try:
        res = requests.get(url, headers=headers, timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data.get("videos"):
                # Obter o link do arquivo com melhor resolução Full HD
                video_files = data["videos"][0]["video_files"]
                best_file = max(video_files, key=lambda x: x.get("width", 0))
                video_url = best_file["link"]
                
                # Download do clipe
                clip_data = requests.get(video_url, timeout=20).content
                os.makedirs(os.path.dirname(target_filepath), exist_ok=True)
                with open(target_filepath, "wb") as f:
                    f.write(clip_data)
                return True
    except Exception as e:
        logging.warning(f"Falha ao baixar B-roll para a busca '{query}': {str(e)}")
    return False

5.3 O Motor de Renderização Programática via FFmpeg (agents/video_editor.py)

O FFmpeg é o padrão industrial absoluto para processamento de vídeo headless
(sem interface gráfica). Ele consome frações mínimas dos recursos computacionais
se comparado a softwares tradicionais (Premiere, After Effects), permitindo que
a renderização ocorra localmente de forma silenciosa ou em servidores remotos
através de chamadas de subprocesso Python.

                      PIPELINE DE MONTAGEM DO FFMPEG
                      
 [ Clipes de B-Roll (25 a 35 assets) ]
                   |
                   v
 [ Normalização de Resolução & FPS ] --------> scale=1080:1920, fps=30
                   |
                   v
 [ Efeito Dinâmico (Ken Burns Zoom) ] -------> zoompan (Zoom sutil de 1.0 a 1.15)
                   |
                   v
 [ Concatenação e Cortes Rápidos ] ----------> Concat Video Filtergraph
                   |
                   +<--- [ Injeção de Áudio Mestre (-14 LUFS) ]
                   |
                   +<--- [ Trilha Sonora de Fundo em Ducking (-22dB) ]
                   |
                   +<--- [ Efeitos Sonoros Pontuais (SFX whoosh/thud) ]
                   |
                   +<--- [ Queima de Legendas Dinâmicas (.ASS/.SRT) ]
                   |
                   v
 [ VÍDEO FINAL RENDERIZADO (.MP4) ] ---------> H.264 / AAC (High Quality)

O Script de Montagem Automatizada (agents/video_editor.py)

Este script unifica todas as peças: corta os clipes de B-roll nos tempos exatos
de cada frase, normaliza o formato visual, aplica a trilha sonora suavizada em
segundo plano (audio ducking) e grava as legendas dinâmicas no centro inferior
da tela com tipografia de alto contraste.

"""
agents/video_editor.py
Motor de renderização e composição automatizada via chamadas diretas ao FFmpeg.
"""

import os
import json
import argparse
import subprocess
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - [RENDER] - %(levelname)s - %(message)s")

class VideoRenderer:
    def __init__(self, target_resolution: str = "1080x1920", fps: int = 30):
        self.width, self.height = target_resolution.split("x")
        self.fps = fps

    def render_short(
        self,
        clips_dir: str,
        audio_path: str,
        srt_path: str,
        sfx_path: str,
        bg_music_path: str,
        output_file: str
    ):
        """Compila todos os ativos em um vídeo vertical pronto para distribuição."""
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # 1. Mapear arquivos de vídeo da pasta de B-Roll ordenados
        broll_files = sorted([
            os.path.join(clips_dir, f) for f in os.listdir(clips_dir) 
            if f.endswith((".mp4", ".mov"))
        ])

        if not broll_files:
            raise FileNotFoundError(f"Nenhum clipe de vídeo encontrado em: {clips_dir}")

        # 2. Construir lista de concatenação temporária para o FFmpeg
        concat_list_path = "cache/concat_list.txt"
        with open(concat_list_path, "w", encoding="utf-8") as f:
            for clip in broll_files:
                # Normaliza caminhos absolutos para compatibilidade Windows/Linux
                escaped_path = os.path.abspath(clip).replace("\\", "/")
                f.write(f"file '{escaped_path}'\n")

        # 3. Estilização avançada de legenda para forçar Montserrat/Bold amarela/branca
        # Formato de escape do FFmpeg para legendas com estilo customizado
        subtitles_filter = (
            f"subtitles='{srt_path.replace(':', r'\:')}':force_style="
            "'Fontname=Montserrat,FontSize=18,PrimaryColour=&H00FFFFFF,"
            "SecondaryColour=&H0000FFFF,OutlineColour=&H00000000,BackColour=&H80000000,"
            "Bold=1,Outline=2,Shadow=2,Alignment=2,MarginV=180'"
        )

        # 4. Construção do comando unificado de renderização
        # Aplica:
        # - Concatenação com loop de segurança
        # - Redimensionamento e corte central para 1080x1920
        # - Mixagem do áudio mestre + trilha de fundo suavizada (-22dB)
        # - Queima de legenda integrada
        ffmpeg_cmd = [
            "ffmpeg", "-y",
            "-f", "concat", "-safe", "0", "-i", concat_list_path,
            "-i", audio_path,
            "-i", bg_music_path,
            "-filter_complex",
            (
                f"[0:v]scale={self.width}:{self.height}:force_original_aspect_ratio=increase,"
                f"crop={self.width}:{self.height},"
                f"fps={self.fps},{subtitles_filter}[v];"
                f"[2:a]volume=0.08[bgm];"
                f"[1:a][bgm]amix=inputs=2:duration=first:dropout_transition=2[a]"
            ),
            "-map", "[v]",
            "-map", "[a]",
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "19",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            output_file
        ]

        logging.info("Iniciando renderização FFmpeg de alta precisão...")
        process = subprocess.run(ffmpeg_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        if process.returncode != 0:
            logging.error(f"Erro na renderização do FFmpeg:\n{process.stderr}")
            raise RuntimeError("Falha na compilação do vídeo final.")

        logging.info(f"Vídeo compilado com sucesso absoluto: {output_file}")

def main():
    parser = argparse.ArgumentParser(description="Renderizador Automático FFmpeg")
    parser.add_argument("--clips-dir", type=str, required=True, help="Diretório dos clipes de B-Roll baixados")
    parser.add_argument("--audio", type=str, required=True, help="Arquivo de narração .mp3")
    parser.add_argument("--srt", type=str, required=True, help="Arquivo de legendas sincronizadas .srt")
    parser.add_argument("--bg-music", type=str, default="templates/audio/ambient_tension.mp3", help="Trilha de fundo")
    parser.add_argument("--output", type=str, default="output/final_video.mp4", help="Arquivo final de saída")
    args = parser.parse_args()

    renderer = VideoRenderer()
    renderer.render_short(
        clips_dir=args.clips_dir,
        audio_path=args.audio,
        srt_path=args.srt,
        sfx_path="",
        bg_music_path=args.bg_music,
        output_file=args.output
    )

if __name__ == "__main__":
    main()

5.4 Padronização de Miniaturas (Thumbnails) de Alta Taxa de Clique (CTR)

No formato horizontal de vídeo longo (Hub), a miniatura é responsável por mais
de 70% do sucesso algorítmico do vídeo. Uma miniatura amadora destrói o tráfego
antes mesmo do algoritmo avaliar a retenção interna.

A esteira gera automaticamente os conceitos de miniatura estruturados no JSON de
metadados, aplicando os três mandamentos das thumbnails internacionais de alto
clique:

                  ANATOMIA DE UMA THUMBNAIL DE ALTA CTR
                  
+--------------------------------------------------------------------------+
|  [ PRIMEIRO PLANO ]          [ TEXTO DE IMPACTO ]       [ PLANO DE FUNDO]|
|  Elemento isolado em         Máximo 3 a 4 palavras.     Cenário com      |
|  altíssimo contraste e       Fonte bold sem serifa      iluminação de    |
|  recorte cirúrgico           (Impact ou Montserrat).    borda (Rim Light)|
|  (ex: Rosto 3D, gráfico,     Cor: Amarelo/Branco        e profundidade de|
|  objeto icônico em crise)    com sombra pesada.         campo desfocada. |
+--------------------------------------------------------------------------+

Regras Estritas de Composição:

1.  Regra das Três Palavras: O texto da miniatura nunca repete o título do
    vídeo. Ele complementa o título criando um novo conflito cognitivo (ex.: se
    o título é "Why Rome Really Collapsed", o texto da miniatura estampa apenas:
    "THE SILENT POISON").
2.  Contraste de Luminância: O elemento principal deve registrar pelo menos 60%
    de contraste de cor em relação ao plano de fundo.
3.  Escala para Telas Mobile: Mais de 80% das impressões ocorrem em smartphones.
    A imagem deve ser legível e compreensível quando reduzida ao tamanho de uma
    moeda de 1 real na tela do celular.

5.5 Checklist Tático de Conclusão da Etapa 5

Antes de avançar para a montagem dos mecanismos de captura de receita imediata e
integração de checkout global na Etapa 6, a esteira de renderização deve atender
integralmente aos seguintes requisitos técnicos:

- [ ] Síntese Vocal Homologada com Timestamps: Áudio exportado em padrão
  broadcast (-14 LUFS) sem artefatos mecânicos e com arquivo .srt sincronizado
  palavra por palavra.
- [ ] Módulo de Mídia Parametrizado: Download de B-roll funcional, gerando uma
  biblioteca temporária de pelo menos 25 clipes verticais de alta resolução para
  cada 60 segundos de vídeo.
- [ ] Binário do FFmpeg Instalado e Acessível Globalmente: O comando ffmpeg
  -version responde corretamente no terminal da máquina ou ambiente virtual.
- [ ] Renderização de Teste sem Quebra de Frame: Compilação do arquivo de teste
  executada do início ao fim com exportação em codec H.264, áudio AAC e queima
  de legenda estilizada sem cortes nas bordas da tela.
- [ ] Estrutura de Armazenamento Temporário Limpa: O diretório cache/ armazena e
  expurga os arquivos brutos intermediários após o término de cada renderização
  para evitar estouro de memória em disco.
