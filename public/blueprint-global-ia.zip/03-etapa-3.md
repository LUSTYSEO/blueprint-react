# ETAPA 3: A ENGENHARIA DO HUB & SPOKE, PSICOLOGIA DA RETENÇÃO E ESTRUTURAÇÃO NARRATIVA DE ALTA CONVERSÃO

---

## 3.1 O Ecossistema de Distribuição em Cascata (O Conceito Hub & Spoke)

Um dos erros capitais de operadores iniciantes no mercado de conteúdo orgânico é apostar exclusivamente em formatos curtos (*Shorts, TikTok, Reels*) ou unicamente em formatos longos tradicionais. 

* **Operar apenas com formatos curtos** gera picos rápidos de visualização e inscritos, mas resulta em um **RPM irrisório** (frequentemente entre $\$0.04$ e $\$0.15$ por mil visualizações no fundo de bônus de Shorts), além de criar uma audiência volátil, de baixa fidelidade e com dispersão atencional severa, o que dificulta conversões em ofertas de valor mais elevado.
* **Operar apenas com vídeos longos** cria ativos de alto valor e monetização robusta no AdSense (RPM de $\$8.00$ a $\$35.00+$), porém enfrenta uma barreira fria de descoberta: o algoritmo exige histórico de engajamento prévio para conceder impressões massivas na página inicial (*Browse Features*).

A solução arquitetural definitiva para essa dicotomia é o **Ecossistema Hub & Spoke (Eixo Central e Raios de Distribuição)**.

```
                  ARQUITETURA EM CASCATA: HUB & SPOKE
                  
                       [ HUB: CONTEÚDO CENTRAL ]
                  Vídeo Longo Analítico / Documental
                        (8 a 15 min - 16:9)
                       Monetização: Alto RPM
                                 |
         +-----------------------+-----------------------+
         |                       |                       |
         v                       v                       v
  [ SPOKE 1: Hook ]       [ SPOKE 2: Insight ]    [ SPOKE 3: Parodox ]
    Short / Reel            Short / TikTok          Short / Pin
     (9:16 vertical)         (9:16 vertical)         (9:16 vertical)
         |                       |                       |
         +-----------------------+-----------------------+
                                 |
                                 v
                     [ PONTOS DE CONVERSÃO ]
          ┌──────────────────────┴──────────────────────┐
          ▼                                             ▼
  [ Tráfego Interno ]                           [ Funil Externo ]
  Link Direcionado para o Hub                   Link da Bio / DM Automática
  (Aumento de Watch Time Global)                (Venda de Infoprodutos/Afiliados)
```

### A Função de Cada Componente

1. **O Hub (Eixo Central):** Consiste em um vídeo horizontal (16:9) de alta densidade informativa, com duração entre **8 e 15 minutos**. É o ativo patrimonial do canal. Ele é estruturado para maximizar o tempo de retenção na plataforma (*Watch Time*), reter sessões longas e comportar a inserção de múltiplos anúncios intermediários (*Mid-roll Ads*).
2. **Os Spokes (Raios de Distribuição):** São 3 a 5 fragmentos verticais (9:16) extraídos, reformatados ou concebidos paralelamente a partir do tema do Hub, com duração entre **30 e 55 segundos**. O objetivo exclusivo do Spoke é capturar a atenção rápida no feed algorítmico, validar o interesse do usuário em frações de segundo e atuar como vetor de direcionamento duplo:
   * **Direcionamento Interno:** Através do recurso de "Vídeo Relacionado" (*Related Video*) nativo do YouTube Shorts, o Spoke transfere o tráfego frio diretamente para o vídeo Hub longo, alimentando a métrica que o algoritmo mais valoriza: **sessões profundas de visualização**.
   * **Direcionamento Externo:** Conduz o usuário para a automação de comentários (ex.: "Comente 'SISTEMA' para receber o documento completo via DM"), alimentando a base de leads e a conversão de infoprodutos.

---

## 3.2 A Neurociência da Retenção Algorítmica

Os algoritmos de distribuição de vídeo modernos (YouTube, Meta, ByteDance) são orientados por redes neurais de aprendizado profundo que avaliam sinais comportamentais em escala de milissegundos. Duas variáveis matemáticas governam o sucesso absoluto de qualquer conteúdo:

$$\text{Distribuição Algorítmica} = f(\text{CTR}, \text{APV}, \text{AVD}, \text{Velocidade de Engajamento})$$

Onde:
* **CTR (Click-Through Rate):** Taxa de clique na impressão (Título + Miniatura).
* **APV (Average Percentage Viewed):** Porcentagem média assistida em relação à duração total do vídeo.
* **AVD (Average View Duration):** Tempo total bruto retido na tela (em segundos ou minutos).

### A Matriz Quantitativa de Aprovação Algorítmica

Para que o sistema de recomendação empurre o conteúdo para além da base de testes e o entregue para centenas de milhares de usuários em países Tier 1, o vídeo precisa atingir os seguintes parâmetros de corte nas primeiras 48 horas:

| Formato | Métrica Crítica Primária | Métrica Crítica Secundária | Benchmark Mínimo para Escala | Benchmark para Explosão Viral |
| :--- | :--- | :--- | :--- | :--- |
| **Vídeo Curto (Shorts / Reels)** | **Viewed vs. Swiped Away** | Retenção Média (APV) | $> 70\%$ optaram por assistir | $> 82\%$ assistiram com **APV $\ge 100\%$** |
| **Vídeo Longo (8 a 15 min)** | **Retenção aos 30 segundos** | Retenção Final aos 8 min | $> 65\%$ continuam no vídeo | $> 50\%$ retidos após 8 minutos |
| **Geral (Horizontal 16:9)** | **CTR de Impressões** | AVD Médio Global | CTR entre $5.5\% - 7.5\%$ | CTR $> 9.0\%$ com AVD $> 6.5 \text{ min}$ |

```
CURVA DE RETENÇÃO TÍPICA: AMADOR vs. ENGENHARIA DE ATENÇÃO

Retenção (%)
100% |==============================\
     |                              \ (Queda Comum: Falta de Gancho)
 70% |  -----------------------------\----------------------------- Linha Crítica de Escala
     |                                \======\ (Engenharia: Micro-Loops)
 50% |                                        \==================== (Retenção Hub 8+ min)
     |                                                 \
  0% +--------------------------------------------------\----------> Tempo
     0s    30s    1m            3m            6m            9m
```

### A Regra dos 2.5 Segundos e Quebra de Padrão (Pattern Interrupts)

A dopamina é liberada pelo cérebro humano diante da **antecipação de novidade**, e não pela conclusão em si. Se um vídeo mantiver o mesmo enquadramento estático, a mesma modulação de voz ou a mesma imagem de fundo por mais de 3 segundos, o cérebro do espectador entra no modo cognitivo de repouso e aciona o movimento involuntário de rolagem de tela (*Swipe-away*).

Para manter o cérebro engajado, aplica-se o protocolo de **Micro-Estímulos Periódicos a cada 1.5 a 2.5 segundos**:
1. **Alternância de Planos Visuais:** Transição contínua entre B-roll temático, zooms digitais suaves (100% para 115%), gráficos dinâmicos de linha e isolamento tipográfico.
2. **Punição ao Silêncio (Zero Dead Air):** Eliminação microscópica de pausas respiratórias e silêncios entre palavras via scripts automatizados de corte.
3. **SFX Pontual (Efeitos Sonoros de Marcação):** Inserção de sons de transição em baixa frequência (*whoosh*, cliques secos de máquina, baixos abafados) exatamente no instante em que um novo conceito visual é projetado na tela.

---

## 3.3 A Estrutura de Retenção de Vídeo Curto (Shorts/Reels - 45 a 60 Segundos)

Para vídeos verticais, a narrativa é dividida em quatro blocos cirúrgicos milimetricamente cronometrados:

```
+-------------------------------------------------------------------------+
| ESTRUTURA CRONOMETRADA DE UM SHORT DE ALTA RETENÇÃO (60s)               |
+-------------------------------------------------------------------------+
| Bloco 1: O Gancho Visceral (0s - 3s)                                    |
| - Quebra de padrão auditiva e visual simultânea                         |
| - Proibição absoluta de cumprimentos ("Hey guys")                       |
+-------------------------------------------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
| Bloco 2: A Agitação do Problema & Open Loop (3s - 15s)                  |
| - Formulação do conflito que desafia o senso comum                      |
| - Instalação da tensão não resolvida (Pergunta implícita)               |
+-------------------------------------------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
| Bloco 3: A Entrega Condensada / O "Miolo" (15s - 45s)                   |
| - Desenvolvimento em formato de 3 passos ou revelação contínua          |
| - Mudança de estímulo visual a cada 2 segundos                          |
+-------------------------------------------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
| Bloco 4: O Fechamento do Loop & Micro-CTA Invisível (45s - 60s)         |
| - Resposta à pergunta inicial                                           |
| - Condução para palavra-chave na DM ou repetição infinita (Loop)        |
+-------------------------------------------------------------------------+
```

### O Protocolo do Loop Perfeito (Seamless Loop)
Uma técnica avançada para forçar o algoritmo a registrar mais de 100% de APV em vídeos verticais é o **Seamless Loop**. A última frase do vídeo conecta-se sintaticamente com a primeira palavra do gancho, eliminando o ponto final perceptível:

* **Frase Final do Vídeo:** *"...and that is the exact reason why your brain falls into..."*
* **Frase Inicial do Gancho (Repetição):** *"...The Constant Distraction Trap! You see, most people believe..."*

Quando o espectador percebe que o vídeo acabou, ele já consumiu os primeiros 2 segundos da repetição, inflando artificialmente as métricas de retenção computadas pela plataforma.

---

## 3.4 Arquitetura do Vídeo Longo para Maximizar RPM (8 a 15 Minutos)

Vídeos com duração superior a 8 minutos possuem uma propriedade comercial determinante: a plataforma permite a inserção manual ou algorítmica de **Mid-rolls (anúncios no meio do vídeo)**. Enquanto um vídeo de 5 minutos exibe apenas anúncios na entrada e na saída, um vídeo de 12 minutos com alta retenção pode veicular 3 a 4 impressões publicitárias para o mesmo usuário, multiplicando o RPM real daquele ativo.

```
                  CRONOGRAMA DE ENGENHARIA DE MID-ROLLS
                  
Minutos:  0:00        2:30        5:00        8:00        11:00       13:30
          |-----------|-----------|-----------|-----------|-----------|
Picos de  [Gancho     [Mini-Loop  [Ponto de   [Mid-roll   [Resolução  [Outro &
Tensão:    Inicial]    Resolvido]  Virada]     Crítico]    do Clímax]  Next Video]
                      (Anúncio 1)             (Anúncio 2)             (Anúncio 3)
```

### A Estrutura em Quatro Atos para Canais Faceless

#### Ato 1: O Gancho Cinematográfico e o Incidente Incitante (0:00 - 1:30)
* **Objetivo:** Estabelecer a promessa primária do vídeo e criar um abismo de curiosidade (*Curiosity Gap*).
* **Mecânica:** Os primeiros 30 segundos não explicam a solução; eles dramatizam as consequências de ignorar o problema. Mostra-se o resultado final antes de mostrar o processo (ex.: em um vídeo sobre produtividade, mostra-se o sistema funcionando de forma elegante antes de explicar como montá-lo; em um vídeo histórico, inicia-se no momento da queda do império, não no nascimento).

#### Ato 2: A Desconstrução do Mito e o Ponto Cego (1:30 - 5:30)
* **Objetivo:** Destruir a crença convencional que o público tem sobre o assunto.
* **Mecânica:** Apresentam-se dados, evidências visuais e comparações contrárias ao senso comum. É o momento de posicionar o narrador como uma fonte analítica confiável e neutra, sem apelar para excesso de jargões técnicos.

#### Ato 3: A Reconstrução Mecânica / O Método Oculto (5:30 - 10:00)
* **Objetivo:** Entregar a estrutura prática do que foi prometido no início.
* **Mecânica:** Dividir o conteúdo em etapas sequenciais (Passo 1, Passo 2, Passo 3). O cérebro humano se agarra à previsibilidade de listas. O operador posiciona estrategicamente o primeiro anúncio Mid-roll exatamente entre a transição do Passo 1 para o Passo 2, momento em que o abandono é estatisticamente nulo porque o usuário já está investido no desfecho.

#### Ato 4: A Conclusão Expansiva e o Binge-Watching Trigger (10:00 - 13:00)
* **Objetivo:** Impedir a queda de audiência final e transferir o usuário para o próximo vídeo do canal.
* **Mecânica:** **Nunca anuncie o fim do vídeo.** Frases como *"In conclusion"*, *"To wrap things up"* ou *"Thank you for watching"* acionam a saída imediata do usuário. 
* Em vez disso, amarre a última lição a uma pergunta que só é respondida no vídeo seguinte: *"Now that you understand this mechanism, there is still one fatal flaw you must avoid, and that is exactly what we broke down in this video right here on the screen."* O vídeo encerra com um corte seco, apontando para o card final.

---

## 3.5 Matriz de Gatilhos Semânticos e Palavras-Chave de Conversão

A retenção deve trabalhar a serviço da conversão financeira. Para canais voltados ao mercado americano e europeu, certos gatilhos verbais acionam respostas comportamentais padronizadas na audiência.

| Gatilho Psicológico | Palavras-Chave em Inglês (Alto Impacto) | Efeito Comportamental no Espectador |
| :--- | :--- | :--- |
| **Escassez de Informação** | *"The hidden archive", "What they omitted", "The undocumented flaw"* | Aumenta o valor percebido do dado entregue; induz o foco imediato. |
| **Quebra de Dogma** | *"Counter-intuitive", "The efficiency paradox", "The biological myth"* | Desperta a atenção involuntária por desafiar crenças arraigadas. |
| **Redução de Fricção** | *"Step-by-step blueprint", "Zero guesswork", "Direct plug-and-play"* | Converte espectadores preguiçosos em compradores de templates/ebooks. |
| **Chamada de DM Nativa** | *"Comment 'SYSTEM' below", "Type 'BLUEPRINT'", "Drop 'ACCESS'"* | Gera alto volume de comentários (sinal verde para o algoritmo) e aciona o bot. |

---

## 3.6 Master Prompt de Roteirização Estruturada para Modelos de Linguagem

Para garantir que o agente de inteligência artificial (Claude, GPT-4) gere roteiros calibrados para retenção e prontos para edição sem exigir reescritas manuais exaustivas, utiliza-se um **System Prompt Parametrizado**.

Este prompt força a IA a produzir o roteiro já com os comandos de cena, instruções de entonação para o software de voz sintética e marcação exata de B-roll a cada 2 segundos.

```markdown
### MASTER PROMPT DE ROTEIRIZAÇÃO (SYSTEM DIRECTIVE)

Atue como um Roteirista Chefe e Diretor de Retenção especializado em documentários faceless e ensaios de alta performance para o YouTube internacional (EUA/UK).

Sua tarefa é transformar o tema fornecido em um roteiro completo, denso e magneticamente retentivo, seguindo rigorosamente os parâmetros de engenharia de atenção.

#### DIRETRIZES FUNDAMENTAIS DE ESCRITA:
1. Idioma: Inglês Nativo dos Estados Unidos (en-US), tom analítico, confiante, cinematográfico e contido. Sem frases clichês ou exageros vazios.
2. Proibições Absolutas: Nunca use cumprimentos ("Welcome back", "Hey guys"). Nunca anuncie o fim do vídeo ("In conclusion", "Finally"). Sem enrolação nos primeiros 30 segundos.
3. Ritmo de Fala: Frases curtas, diretas, intercalando sentenças longas com sentenças de impacto de 3 a 5 palavras.
4. Densidade Visual: Cada linha de narração DEVE ser acompanhada por sua respectiva instrução técnica de visual (B-roll, Motion Graphic, Tipografia ou Arquivo Histórico).

#### ESTRUTURA OBRIGATÓRIA DA RESPOSTA:

[METADATA DO VÍDEO]
- Título Sugerido 1 (Quebra de Padrão):
- Título Sugerido 2 (Revelação do Erro Oculto):
- Título Sugerido 3 (Superlativo de Curiosidade):
- Conceito Visual da Thumbnail (Foreground, Background, Texto de 3 palavras):

[ESTRUTURA DO ROTEIRO COM TIMESTAMPS]

| Timestamp | Seção Narrativa | Narração (Voiceover) | Instrução Visual (B-Roll & On-Screen Text) | SFX & Trilha Sonora |
| :--- | :--- | :--- | :--- | :--- |
| 00:00 - 00:05 | Hook Visual & Auditivo | [Texto da primeira frase impactante] | [Descrição exata do ativo visual em 4K, corte rápido] | [Efeito sonoro pontual de impacto seco] |
| 00:05 - 00:20 | Abertura do Loop | [Texto que agita o conflito central] | [Gráficos dinâmicos ou cenas de arquivo em alto contraste] | [Trilha de tensão subindo em baixa frequência] |
| ... | ... | ... | ... | ... |

[INSTRUÇÃO DO CALL TO ACTION]
- Comando exato de fechamento amarrando a palavra-chave de engajamento nos comentários para automação de funil.
```

---

## 3.7 Checklist Tático de Conclusão da Etapa 3

Antes de avançar para a montagem da esteira de código com Claude Code e scripts Python na **Etapa 4**, o fluxo de produção de roteiros deve satisfazer os seguintes critérios:

- [ ] **Mapeamento Hub & Spoke Estabelecido:** Cada tema central possui previsão de 1 vídeo longo (8 a 15 min) e 3 ganchos curtos verticais (Shorts/Reels) planejados.
- [ ] **Validação do Gancho nos Primeiros 3 Segundos:** O roteiro inicia diretamente no conflito, sem apresentações ou saudações.
- [ ] **Cadência de Estímulos Visuais Parametrizada:** Nenhuma tomada no roteiro permanece estática por mais de 2.5 segundos nas instruções técnicas de B-roll.
- [ ] **Janelas de Mid-Roll Mapeadas (Vídeo Longo):** Pausas naturais de tensão projetadas entre os minutos 4:00, 8:00 e 11:00 para alocação de anúncios sem destruição da retenção.
- [ ] **Gatilho de Comentário para Funil (CTA) Inserido:** Palavra-chave definida no roteiro para acionamento de envio automático de links via DM.