# ETAPA 4: AUTOMAÇÃO TOTAL COM CLAUDE CODE (CLI): ARQUITETURA MULTIAGENTE, SCRIPTS PYTHON E FLUXO DE EXECUÇÃO

---

## 4.1 A Infraestrutura do Claude Code como Orquestrador de Sistema

O desenvolvimento de uma esteira massiva de conteúdo orgânico não pode depender de interfaces gráficas convencionais de chat web (onde o operador copia e cola comandos repetitivamente). Para alcançar escala industrial com uma equipe reduzida ou operação solo, adota-se o **Claude Code (a interface de linha de comando/CLI da Anthropic)** como o orquestrador autônomo do ambiente local.

Diferente de um modelo de linguagem passivo, um agente operando via CLI possui capacidades operacionais de baixo nível:
1. **Manipulação Autônoma do Sistema de Arquivos:** Leitura, criação, edição e estruturação de pastas, scripts e arquivos de configuração.
2. **Execução Direta de Subprocessos e Comandos Bash:** Execução de scripts Python, chamadas de compiladores, comandos FFmpeg e automações de terminal.
3. **Loop de Autoavaliação e Correção de Erros:** Identificação de exceções de código (*tracebacks*), falhas de APIs externas ou problemas de formatação, corrigindo o script em tempo real sem interrupção humana.

```
                  ARQUITETURA DO CLAUDE CODE ORCHESTRATOR
                  
                  +----------------------------------------+
                  |        CLAUDE CODE CLI (Terminal)      |
                  |     Governança via arquivo CLAUDE.md   |
                  +-------------------+--------------------+
                                      |
         +----------------------------+----------------------------+
         |                            |                            |
         v                            v                            v
+------------------+         +------------------+         +------------------+
| AGENT 1: ANALYZER|         |AGENT 2: WRITER   |         | AGENT 3: DIRECTOR|
| YouTube Data API | ------> | Anthropic API    | ------> | FFmpeg Engine    |
| Filtro de Outlier|  (JSON) | Roteiro & SEO    |  (SRT)  | Renderização     |
+------------------+         +------------------+         +------------------+
                                                                   |
                                                                   v
                                                          +------------------+
                                                          |AGENT 4: PUBLISHER|
                                                          | Upload Automático|
                                                          | Loop de Feedback |
                                                          +------------------+
```

### Estrutura de Diretórios Padronizada do Projeto

Para garantir que o agente opere com contexto delimitado e determinismo estrito, o repositório local deve seguir uma topologia de pastas padronizada:

```text
youtube-automation-agent/
├── CLAUDE.md                    # Diretrizes operacionais e regras de sistema do agente
├── .env                         # Chaves de API (YouTube Data API, Anthropic, ElevenLabs/Fish)
├── requirements.txt             # Dependências Python do ecossistema
├── config/
│   ├── channels.json            # Configurações de nicho, idioma e metas de cada canal
│   └── proxies.json             # Parâmetros de rede e proxies residenciais alocados
├── agents/
│   ├── analyzer.py              # Agente 1: Mineração de dados e detecção de outliers
│   ├── scriptwriter.py          # Agente 2: Roteirização estruturada e engenharia de SEO
│   ├── media_generator.py       # Agente 3A: Síntese de voz e aquisição de B-roll
│   ├── video_editor.py          # Agente 3B: Renderização automatizada via FFmpeg
│   └── publisher.py             # Agente 4: Agendamento e envio via API
├── templates/
│   ├── prompt_templates.json    # Prompts parametrizados para cada arquétipo de vídeo
│   └── sfx/                     # Biblioteca de efeitos sonoros em baixa frequência (.wav)
├── cache/                       # Armazenamento temporário de áudios (.mp3) e legendas (.srt)
└── output/                      # Vídeos finais renderizados e relatórios de métricas (.json)
```

---

## 4.2 O Arquivo de Governança do Agente (`CLAUDE.md`)

O arquivo `CLAUDE.md` na raiz do projeto atua como a constituição operacional do Claude Code. Toda vez que o terminal do agente é inicializado dentro da pasta, ele carrega estas diretrizes na janela de contexto de longo prazo, garantindo que o modelo nunca se desvie das regras de negócio.

```markdown
# PROTOCOLO OPERACIONAL DO AGENTE (CLAUDE.md)

Você é o Orquestrador Central da Esteira de Automação de Conteúdo Orgânico Global.
Sua responsabilidade é gerenciar os agentes em `agents/`, validar dados de entrada/saída e executar comandos no terminal de forma autônoma e segura.

## DIRETRIZES DE EXECUÇÃO:
1. Determinismo e Formato: Toda comunicação entre scripts Python deve ocorrer estritamente via JSON na pasta `cache/`. Nunca use formatos não estruturados.
2. Tratamento de Erros: Se um script retornar `Exit Code != 0`, analise o traceback, identifique se o erro deriva de limite de taxa de API (Rate Limit), sintaxe ou rede, corrija o script ou aplique *Exponential Backoff* antes de interromper a execução.
3. Segurança de Rede: Nunca realize requisições diretas a redes sociais sem validar previamente se o proxy correspondente em `config/proxies.json` está ativo e saudável.
4. Padrão de Código: Todo código Python deve seguir PEP 8, com tipagem estática (Type Hints) e logs em nível INFO e ERROR utilizando o módulo padrão `logging`.

## COMANDOS PERMITIDOS DE TERMINAL:
- `python agents/analyzer.py --nicho <nicho_id>`
- `python agents/scriptwriter.py --topic-file <caminho_json>`
- `python agents/video_editor.py --render-batch <batch_id>`
```

---

## 4.3 Agente 1: Mineração de Dados e Detecção de Outliers (`agents/analyzer.py`)

O primeiro agente de software conecta-se à **YouTube Data API v3** para monitorar continuamente os canais concorrentes catalogados na Etapa 1. O script calcula automaticamente o *Outlier Score* ($OS$) e o *Views per Hour* ($V/H$) dos vídeos mais recentes, filtrando apenas as pautas com tração matemática comprovada.

```python
"""
agents/analyzer.py
Responsável por minerar concorrentes via YouTube Data API v3 e filtrar tópicos outliers.
"""

import os
import json
import argparse
import logging
from datetime import datetime, timezone
from typing import List, Dict, Any
from googleapiclient.discovery import build
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")

class ContentAnalyzer:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("YOUTUBE_API_KEY não foi encontrada no ambiente.")
        self.youtube = build("youtube", "v3", developerKey=api_key)

    def get_channel_videos(self, channel_id: str, max_results: int = 20) -> List[Dict[str, Any]]:
        """Extrai os últimos vídeos de um canal mapeado."""
        try:
            # 1. Obter o ID da playlist de uploads do canal
            channel_resp = self.youtube.channels().list(
                part="contentDetails",
                id=channel_id
            ).execute()
            
            uploads_playlist_id = channel_resp["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]
            
            # 2. Obter a lista de vídeos da playlist
            playlist_resp = self.youtube.playlistItems().list(
                part="contentDetails",
                playlistId=uploads_playlist_id,
                maxResults=max_results
            ).execute()
            
            video_ids = [item["contentDetails"]["videoId"] for item in playlist_resp.get("items", [])]
            
            # 3. Extrair estatísticas detalhadas dos vídeos
            videos_resp = self.youtube.videos().list(
                part="snippet,statistics",
                id=",".join(video_ids)
            ).execute()
            
            return videos_resp.get("items", [])
        except Exception as e:
            logging.error(f"Erro ao extrair dados do canal {channel_id}: {str(e)}")
            return []

    def calculate_outlier_metrics(self, videos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Calcula a mediana do canal e o Outlier Score de cada vídeo."""
        if len(videos) < 5:
            return []

        # Extrair visualizações brutas
        views = [int(v["statistics"].get("viewCount", 0)) for v in videos]
        
        # Calcular a mediana estável (excluindo os extremos)
        sorted_views = sorted(views)
        median_views = sorted_views[len(sorted_views) // 2]
        if median_views == 0:
            median_views = 1  # Evita divisão por zero

        validated_outliers = []
        now = datetime.now(timezone.utc)

        for v in videos:
            view_count = int(v["statistics"].get("viewCount", 0))
            published_at = datetime.fromisoformat(v["snippet"]["publishedAt"].replace("Z", "+00:00"))
            
            # Cálculo de idade em horas
            hours_alive = max((now - published_at).total_seconds() / 3600, 1.0)
            
            outlier_score = round(view_count / median_views, 2)
            views_per_hour = round(view_count / hours_alive, 2)

            # Filtro de corte: OS >= 3.0x ou V/H acelerado (> 100 views/hora)
            if outlier_score >= 3.0:
                validated_outliers.append({
                    "video_id": v["id"],
                    "title": v["snippet"]["title"],
                    "description": v["snippet"]["description"],
                    "view_count": view_count,
                    "median_views": median_views,
                    "outlier_score": outlier_score,
                    "views_per_hour": views_per_hour,
                    "published_at": v["snippet"]["publishedAt"]
                })

        # Ordenar pelos maiores Outliers
        validated_outliers.sort(key=lambda x: x["outlier_score"], reverse=True)
        return validated_outliers

def main():
    parser = argparse.ArgumentParser(description="Mapeador de Tópicos Outlier")
    parser.add_argument("--channel", type=str, required=True, help="ID do Canal do YouTube")
    parser.add_argument("--output", type=str, default="cache/outliers.json", help="Caminho do arquivo de saída")
    args = parser.parse_args()

    analyzer = ContentAnalyzer(YOUTUBE_API_KEY)
    logging.info(f"Analisando métricas do canal: {args.channel}")
    
    videos = analyzer.get_channel_videos(args.channel)
    outliers = analyzer.calculate_outlier_metrics(videos)

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(outliers, f, indent=2, ensure_ascii=False)

    logging.info(f"Mapeamento concluído. {len(outliers)} tópicos outliers identificados.")

if __name__ == "__main__":
    main()
```

---

## 4.4 Agente 2: Roteirização Autônoma e Engenharia de SEO (`agents/scriptwriter.py`)

O segundo agente processa os tópicos gerados pelo analisador. Ele utiliza o SDK da Anthropic (`anthropic`) chamando a API do Claude para gerar um roteiro estruturado com timestamps, parâmetros de entonação para o motor de voz e metadados de SEO para o upload.

```python
"""
agents/scriptwriter.py
Consome pautas outliers validadas e sintetiza roteiros profissionais calibrados para retenção.
"""

import os
import json
import argparse
import logging
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class ScriptWriterAgent:
    def __init__(self):
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY não foi encontrada no ambiente.")
        self.client = Anthropic(api_key=api_key)

    def generate_script(self, topic_title: str, reference_desc: str, target_lang: str = "en-US") -> Dict:
        system_prompt = (
            "You are an Elite Video Retention Strategist and Scriptwriter for top-tier faceless channels. "
            "Write exclusively in American English (en-US). Tone: authoritative, analytical, cinematic, and fast-paced. "
            "Structure the output in pure, valid JSON with no markdown wrapping. "
            "The JSON must have this exact schema:\n"
            "{\n"
            '  "seo_metadata": {\n'
            '    "titles": ["Title 1", "Title 2", "Title 3"],\n'
            '    "description": "First 200 chars packed with primary keywords + chapter timestamps",\n'
            '    "tags": ["tag1", "tag2", "tag3"],\n'
            '    "thumbnail_concept": "Detailed foreground and background prompt"\n'
            "  },\n"
            '  "voiceover_script": [\n'
            '    {\n'
            '      "timestamp": "00:00 - 00:03",\n'
            '      "hook_type": "Visual/Audio Pattern Interrupt",\n'
            '      "audio_text": "Exact text to be synthesized by TTS",\n'
            '      "visual_prompt": "Ultra-detailed B-roll search prompt or generator prompt",\n'
            '      "sfx": "low_impact_thud.wav"\n'
            '    }\n'
            "  ]\n"
            "}"
        )

        user_prompt = (
            f"Transform this proven outlier topic into a complete high-retention 60-second video script:\n"
            f"Topic: {topic_title}\n"
            f"Reference Data: {reference_desc}\n"
            f"Ensure a dopamine hit every 2 seconds and a seamless loop at the end."
        )

        logging.info(f"Sintetizando roteiro via Claude para o tema: {topic_title}")

        response = self.client.messages.create(
            model="claude-3-7-sonnet-20250219",
            max_tokens=4000,
            temperature=0.4,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}]
        )

        raw_content = response.content[0].text.strip()
        
        # Sanitização para garantir JSON válido
        if raw_content.startswith("```json"):
            raw_content = raw_content[7:]
        if raw_content.endswith("```"):
            raw_content = raw_content[:-3]

        return json.loads(raw_content.strip())

def main():
    parser = argparse.ArgumentParser(description="Gerador de Roteiros Autônomo")
    parser.add_argument("--input", type=str, default="cache/outliers.json", help="Arquivo JSON com outliers")
    parser.add_argument("--output-dir", type=str, default="cache/scripts/", help="Diretório de saída dos roteiros")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        outliers = json.load(f)

    if not outliers:
        logging.warning("Nenhum tópico outlier encontrado para processar.")
        return

    writer = ScriptWriterAgent()
    os.makedirs(args.output_dir, exist_ok=True)

    # Processar o tópico com maior Outlier Score
    target_topic = outliers[0]
    script_data = writer.generate_script(target_topic["title"], target_topic["description"])

    output_file = os.path.join(args.output_dir, f"script_{target_topic['video_id']}.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(script_data, f, indent=2, ensure_ascii=False)

    logging.info(f"Roteiro gerado e validado salvo em: {output_file}")

if __name__ == "__main__":
    main()
```

---

## 4.5 O Orquestrador do Pipeline de Produção Diária (`orchestrator.py`)

Para que a esteira opere com um único comando de terminal no Claude Code, cria-se o script mestre `orchestrator.py`. Ele encadeia a execução sequencial dos agentes, valida a passagem de parâmetros e gera um relatório consolidado de produção.

```python
"""
orchestrator.py
Script de orquestração do ecossistema. Executa o fluxo ponta a ponta.
"""

import subprocess
import sys
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s - [PIPELINE] - %(levelname)s - %(message)s")

def run_step(command: str, description: str):
    logging.info(f"Iniciando: {description}...")
    result = subprocess.run(command, shell=True)
    if result.returncode != 0:
        logging.error(f"Falha na etapa: {description}. Código de erro: {result.returncode}")
        sys.exit(result.returncode)
    logging.info(f"Concluído com sucesso: {description}\n")

def main():
    logging.info("=== INICIANDO PIPELINE DE PRODUÇÃO MULTIPLATAFORMA ===")
    
    # Etapa 1: Mineração de Outliers
    run_step(
        "python agents/analyzer.py --channel UCX6OQ3DkcsbYNE6H8uQQuVA --output cache/validated_topics.json",
        "Extração e Validação Algorítmica de Concorrentes"
    )

    # Etapa 2: Síntese de Roteiro e SEO
    run_step(
        "python agents/scriptwriter.py --input cache/validated_topics.json --output-dir cache/scripts/",
        "Geração de Roteiro Estruturado e Metadados via Claude"
    )

    logging.info("=== FASE DE TEXTO CONCLUÍDA: DADOS PRONTOS PARA A ESTEIRA DE MÍDIA ===")

if __name__ == "__main__":
    main()
```

---

## 4.6 Checklist Tático de Conclusão da Etapa 4

Antes de avançar para a automação de renderização audiovisual e processamento via FFmpeg na **Etapa 5**, a camada de software deve apresentar conformidade integral nos seguintes testes:

- [ ] **Ambiente Virtual Python Configurado:** Dependências instaladas (`google-api-python-client`, `anthropic`, `python-dotenv`) sem conflito de versões.
- [ ] **Chaves de API Válidas e Injetadas no `.env`:** Acesso homologado à YouTube Data API v3 e Anthropic API.
- [ ] **Arquivo `CLAUDE.md` Operante:** O Claude Code reconhece e respeita as regras de negócio ao ser inicializado no terminal do repositório.
- [ ] **Teste de Mineração Homologado:** O script `analyzer.py` executa e exporta com sucesso um arquivo JSON contendo vídeos com $OS \ge 3.0x$.
- [ ] **Teste de Roteirização Concluído:** O script `scriptwriter.py` produz um JSON rigorosamente estruturado com timestamps, prompts visuais detalhados e metadados de SEO sem erros de sintaxe.